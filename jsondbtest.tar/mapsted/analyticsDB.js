// This represents the database and provides
// interfaces for performing different queries;

function AnalyticsDB(buildings, trans)
{
    this.buildings = buildings; 
    this.analytics =  trans;
    
    this.manufacturers = [];
    this.items = [];
    this.categories = [];
    this.states = [];
    this.countries = [];
    
    this.getPurchaseCostsForMan = function(manufacturer)
    {
	var cost = 0;
	this.analytics.forEach( function (el) {
	    if (el.manufacturer === manufacturer)
	    {
		// first get the usage statistics:
		var infos = el.usage_statistics.session_infos;
		// get all sum the purchases:
		infos.forEach( function(infoEl) {
		    infoEl.purchases.forEach( function (item) {
			cost = cost + item.cost;
		    });
		});
	    }
	});   
	
	return cost;
    };

    this.getPurchaseCostsForCat = function (categoryId) {
	var cost = 0;
	this.analytics.forEach( function (el) {
	    var infos = el.usage_statistics.session_infos;
	    infos.forEach( function(infoEl) {
		infoEl.purchases.forEach( function (item) {
		    if (item.item_category_id == categoryId)
			cost = cost + item.cost;
		});
	    });
	});
	
	return cost;
    };

    this.getPurchasesCountForItem = function (itemID) {
	var cnt = 0;
	this.analytics.forEach( function (el) {
	    var infos = el.usage_statistics.session_infos;
	    infos.forEach( function(infoEl) {
		infoEl.purchases.forEach( function (item) {
		    if (item.item_id == itemID) 
			cnt = cnt + 1;
		});
	    });
	});
	
	return cnt;
    };

    // get the purchasing cost for a given state
    this.getPurchaseCostsForState = function (stateName) {
	var states = db.getBuildingIdsForState(stateName);
	var cost = 0;
	this.analytics.forEach( function (el) {
	    var infos = el.usage_statistics.session_infos;
	    infos.forEach( function(infoEl) {
		if (states.has(infoEl.building_id))
		{
		    infoEl.purchases.forEach( function (item) {
			cost = cost + item.cost;
		    });
		}
	    });
	});
	
	return cost;
    };

    // get the purchasing cost for a given state
    this.getPurchaseCostsForCountry = function (countryName) {
	var countryBuildings = this.getBuildingIdsForCountry(countryName);
	var cost = 0;
	this.analytics.forEach( function (el) {
	    var infos = el.usage_statistics.session_infos;
	    infos.forEach( function(infoEl) {
		if (countryBuildings.has(infoEl.building_id))
		{
		    infoEl.purchases.forEach( function (item) {
			cost = cost + item.cost;
		    });
		}
	    });
	});
	
	return cost;
    };

    this.getBuildingWithHighestPCs = function ()
    {
	var highestPCs = Number.MIN_VALUE;
	var highestPCsBId = 0; // 0 is an invalid id
	var tb = new Map();
	this.analytics.forEach( function (el) {
	    var infos = el.usage_statistics.session_infos;
	    infos.forEach( function(infoEl) {
		if (tb.has(infoEl.building_id))
		{
		    var curBuildingPCs = tb.get(infoEl.building_id);
		    
		    // sum it up for the current building:
		    infoEl.purchases.forEach( function (item) {
			curBuildingPCs = curBuildingPCs + item.cost;
		    });

		    // is it greater than the currrent max:
		    if (curBuildingPCs > highestPCs)
		    {
			//window.alert("current highest: " + highestPCs + ": " +
			//	     infoEl.building_id);
			highestPCs = curBuildingPCs;
			highestPCsBId = infoEl.building_id;
		    }
		}
		else
		{
		    // sum it up for the current building:
		    var curCost = 0;
		    infoEl.purchases.forEach( function (item) {
			curCost = curCost + item.cost;
		    });

		    tb.set(infoEl.building_id, curCost);
		}
	    });
	});
	
	return { id: highestPCsBId, cost: highestPCs };
    };

    // queries on buildings:
    // Get the IDs of all the buildings in the
    // given state
    this.getBuildingIdsForState = function (state)
    {
	var buildingIds = new Set([]); 
	this.buildings.forEach( function(el) {
	    if(el.state === state)
		buildingIds.add(el.building_id);
	});
	
	return buildingIds;
    };

    // Get all the ids of the buildings in a given
    // country
    this.getBuildingIdsForCountry = function (country)
    {
	var buildingIds = new Set([]); 
	this.buildings.forEach( function(el) {
	    if(el.country === country)
		buildingIds.add(el.building_id);
	});
	
	return buildingIds;
    };
}
