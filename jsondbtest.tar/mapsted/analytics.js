// This is an utility function to add event
// to controls/widgets:
function addEvent(el, event, callback) {
    if ("addEventListener" in el) {
	el.addEventListener(event, callback, false);
    } else {
	// add a new method to the node
	el['e' + event + callback] = callback;
	el[event + callback]= function() {
	    el['e' + event + callback](window.event); // call it:
	};
	el.addEvent("on" + event, el[event + callback]);
    }
}

// After the Databases have been loaded
// This function performs the initial
// processing:
function processBuilding(buildings)
{
    db.buildings = buildings;
    var states = new Set([]);
    var countries = new Set([]);
   
    for(var i = 0; i < buildings.length; ++i)
    {
	states.add(buildings[i].state);
	countries.add(buildings[i].country);
    }
        
    db.states = Array.from(states).sort();
    db.countries = Array.from(countries).sort();
}

//usage_statistics{…}
function processAnalytics(analytics)
{
    db.analytics = analytics;
    
    var manufacturers = new Set([]);
    var items = new Set([]);
    var categories = new Set([]);
    
    for(var i = 0; i < analytics.length; ++i)
    {
	manufacturers.add(analytics[i].manufacturer);
	var infos = analytics[i].usage_statistics.session_infos;
	infos.forEach( function(infoEl) {
	    infoEl.purchases.forEach( function (item) {
		items.add(parseInt(item.item_id));
		categories.add(parseInt(item.item_category_id));
	    });
	});
    }

    db.manufacturers = Array.from(manufacturers).sort();
    db.items = Array.from(items).sort();
    db.categories = Array.from(categories).sort();
    
    init();
}

// load the JSON data
function loadJSONDBAnalytics(url)
{
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
	if (xhr.status = 400)
	{
	    var loadedDB = JSON.parse(xhr.responseText);
	    processAnalytics(loadedDB);
	}
    };

    xhr.open('GET', url, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(null);
}

// load JSON db
function loadJSONDB(url)
{
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
	if (xhr.status = 400)
	{
	    var loadedDB = JSON.parse(xhr.responseText);
	    processBuilding(loadedDB);
	}
    };
    
    xhr.open('GET', url, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(null);
}

function init()
{
    var manBtn = document.getElementById("manBtn");
    addEvent(manBtn, "click", function(e) {
	var manName = document.getElementById("manName");
	var cost = db.getPurchaseCostsForMan(manName.value);
	var qResult = document.getElementById("manQResult");
	qResult.innerHTML = "Total purchace cost for " + manName.value +
	    " manufacture devices = $" + cost.toLocaleString();
    });

    var qbtn = document.getElementById("qbtn");
    addEvent(qbtn, "click", function(e) {
	var itemId = document.getElementById("itemId");
	var cnt = db.getPurchasesCountForItem(itemId.value);
	var qResult = document.getElementById("qResult");
	var str = "Total number of times item (item_id = ";
	str += itemId.value + ") was purchased: " + cnt;
	qResult.innerHTML = str;
	//window.alert(str);
    });

    var catBtn = document.getElementById("catBtn");
       addEvent(catBtn, "click", function(e) {
	var categoryId = document.getElementById("categoryId");
	var cost = db.getPurchaseCostsForCat(categoryId.value);
	var qResult = document.getElementById("catQResult");
	var str = "Total purchase cost for item in the (item_category_id = ";
	   str += categoryId.value + "): $" + cost.toLocaleString();
	qResult.innerHTML = str;
       });

    // by state:
    var stateBtn = document.getElementById("stateBtn");
       addEvent(stateBtn, "click", function(e) {
	var stateName = document.getElementById("stateName");
	var cost = db.getPurchaseCostsForState(stateName.value);
	var qResult = document.getElementById("stateQResult");
	   var str = "Total purchase cost in " + stateName.value +
	       " = $" + cost.toLocaleString();
	qResult.innerHTML = str;
	   
       });

    // Add event to the Query button for the Total
    // purchase by a country
    var countryBtn = document.getElementById("countryBtn");
       addEvent(countryBtn, "click", function(e) {
	var countryName = document.getElementById("countryName");
	var cost = db.getPurchaseCostsForCountry(countryName.value);
	var qResult = document.getElementById("countryQResult");
	   var str = "Total purchase cost in " + countryName.value +
	       " = $" + cost.toLocaleString();
	qResult.innerHTML = str;
	   
       });

    // Add event the refresh button to display the
    // building with the most purchase costs:
    var buildingBtn = document.getElementById("buildingBtn");
    addEvent(buildingBtn, "click", function(e) {
	   var qResult = document.getElementById("buildingQResult");
	   var pair = db.getBuildingWithHighestPCs();
	qResult.innerHTML = "id=" + pair.id + " ($" + pair.cost.toLocaleString() + ")";
    });

    // initialize the value, if we redo the db data, the value
    // may change, the refresh button will used to update the
    // the value displayed.
    var qResult = document.getElementById("buildingQResult");
    var pair = db.getBuildingWithHighestPCs();
    qResult.innerHTML = "id=" + pair.id + " ($" + pair.cost.toLocaleString() + ")";

    // populate the manufacturer list:
    var manList = document.getElementById("manName");
    var str = "";
    var selected = "";
    db.manufacturers.forEach(function(el) {
	if (el == selectedManufacturer)
	    selected = "selected='selected'";
	str += '<option value="' + el + '" ' + selected + ">" + el + "</option>";
	selected = "";
    });
    manList.innerHTML = str;
    
    // populate the item list:
    var itemList = document.getElementById("itemId");
    var str = "";
    selected = "";
    db.items.forEach(function(el) {
	//str += '<option value="' + el + '">' + el + "</option>";
	if (el == selectedItem)
	    selected = "selected='selected'";
	str += '<option value="' + el + '" ' + selected + ">" + el + "</option>";
	selected = "";
    });
    itemList.innerHTML = str;

    // populate the cateory list:
    var catList = document.getElementById("categoryId");
    var str = "";
    selected = "";
    db.categories.forEach(function(el) {
	if (el == selectedCategory)
	    selected = "selected='selected'";
	str += '<option value="' + el + '" ' + selected + ">" + el + "</option>";
	selected = "";
    });
    catList.innerHTML = str;

    // populate state list:
    var stateList = document.getElementById("stateName");
    var str = "";
    selected = "";
    db.states.forEach(function(el) {
	if (el == selectedState)
	    selected = "selected='selected'";
	str += '<option value="' + el + '" ' + selected + ">" + el + "</option>";
	selected = "";
    });
    stateList.innerHTML = str;

    // populate the country list:
    var countryList = document.getElementById("countryName");
    var str = "";
    selected = "";
    db.countries.forEach(function(el) {
	if (el == selectedCountry)
	    selected = "selected='selected'";
	str += '<option value="' + el + '" ' +
	    selected + ">" + el + "</option>";
	selected = "";
    });
    countryList.innerHTML = str;
}

// these constants are used as default
// values for the query input; they
// do not have any other significance
const selectedManufacturer = "Samsung";
const selectedItem = 47;
const selectedCategory = 7;
const selectedState = "Ontario";
const selectedCountry ="United States";

// create an instance of the database obj:
var db = new AnalyticsDB(null, null);

// load the and fill db:
loadJSONDB("buildings.json");
loadJSONDBAnalytics("analytics.json");
